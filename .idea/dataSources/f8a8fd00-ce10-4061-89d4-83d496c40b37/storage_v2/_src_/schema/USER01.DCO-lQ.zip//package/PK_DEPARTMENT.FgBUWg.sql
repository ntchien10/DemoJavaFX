create package pk_department as
    function getDeptName (dept_id NUMBER)
        return VARCHAR;

    procedure
        getAllByName (dept_name VARCHAR);

    no_comm exception;
    no_sal  exception;
end pk_department;
/

