create trigger PHONGBAN_TRIG
    before insert
    on PHONGBAN
    for each row
BEGIN
  if(:new.ID is null) then
  SELECT S_PHONGBAN.nextval
  INTO :new.ID
  FROM dual;
  end if;
END;
/

