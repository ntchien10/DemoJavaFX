create view EMPLOYEES_VU as
SELECT  employee_id , last_name EMPLOYEE,
            DEPARTMENT_ID
    FROM    employees
/

