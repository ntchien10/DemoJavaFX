create PACKAGE PK_OUTBOUND AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
    PROCEDURE getList(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_TENGOI IN VARCHAR,
        P_CTKV IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    );
END PK_OUTBOUND;
/

