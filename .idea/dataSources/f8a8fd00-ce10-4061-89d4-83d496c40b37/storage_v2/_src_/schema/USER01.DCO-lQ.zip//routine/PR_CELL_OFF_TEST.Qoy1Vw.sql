create PROCEDURE PR_CELL_OFF_TEST (
P_START_DATE IN DATE,
P_END_DATE IN DATE,
P_THRESHOLD IN PLS_INTEGER,
P_DATA OUT SYS_REFCURSOR
)
AS 
  cursor cell_off_cur is select * from CELL_OFF_TEST where (BSCID, CELLID) in (
    select BSCID, CELLID from CELL_OFF_TEST where day >= p_start_date
        and day <= p_end_date 
    group by BSCID, CELLID having count(*) >= p_threshold    
 ) order by bscid, cellid, day;

 type cell_off_t is table of cell_off_cur%rowtype index by binary_integer;
 l_collect cell_off_t;

 l_cell_off_result cell_off_rectype := cell_off_rectype();
 l_prev_cell CELL_OFF_TEST%rowtype;

 l_result cell_off_rc_table := cell_off_rc_table();

 l_count pls_integer := 0;

BEGIN
    l_prev_cell.day := to_date('1/1/1970', 'dd/mm/yyyy');
    l_prev_cell.cellid := 'cell';
    open cell_off_cur;
    loop
        fetch cell_off_cur bulk collect into l_collect limit 100;
        for l_row in 1..l_collect.count loop
            -- neu chuyen sang cell moi reset lai bo dem 
            -- luu y co mot cac truong hop 2 cell co ten giong nhau thuoc hai bsc khac nhau
            if l_prev_cell.bscid <> l_collect(l_row).bscid 
                or l_prev_cell.cellid <> l_collect(l_row).cellid  
             then
                if l_count >= p_threshold then
                    l_result.extend;
                    l_cell_off_result.start_date := l_prev_cell.day - l_count + 1; 
                    l_cell_off_result.end_date := l_prev_cell.day ; 
                    l_cell_off_result.bscid := l_prev_cell.bscid;
                    l_cell_off_result.cellid := l_prev_cell.cellid;
                    l_cell_off_result.cellname := l_prev_cell.cellname;
                    l_result(l_result.count) := l_cell_off_result;
                end if;

                l_count := 1;  
            elsif l_prev_cell.day + 1 = l_collect(l_row).day then
                l_count := l_count + 1;
            else 
                -- neu ngay khong lien tiep reset lai bo dem
                l_count := 1;
            end if;              

         l_prev_cell := l_collect(l_row);         
        end loop;
        exit when cell_off_cur%notfound;
    end loop;
    close cell_off_cur;

    open p_data for select * from table(l_result);
END PR_CELL_OFF_TEST;
/

