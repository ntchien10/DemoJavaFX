create package body pk_contact AS

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
  PROCEDURE INSERT_CONTACT(
    p_CONTACT_CODE  CONTACTS.CONTACT_CODE%TYPE,
    p_FULLNAME      CONTACTS.FULLNAME%TYPE,
    p_EMAIL         CONTACTS.EMAIL%TYPE,
    p_PHONE         CONTACTS.PHONE%TYPE,
    p_TITLE         CONTACTS.TITLE%TYPE,
    P_MESSAGE       CONTACTS.MESSAGE%TYPE,
    p_USER_TO       CONTACTS.USER_TO%TYPE,
    P_EMAIL_TO      CONTACTS.EMAIL_TO%TYPE,
    p_EMAIL_CC      CONTACTS.EMAIL_CC%TYPE,
    p_PHONE_TO      CONTACTS.PHONE_TO%TYPE,
    p_CREATE_BY     CONTACTS.CREATE_BY%TYPE,
    p_ATTACH_FILE   CONTACTS.ATTACH_FILE%TYPE
  )AS
  BEGIN
    INSERT INTO CONTACTS(
      CONTACT_CODE,
      FULLNAME,
      EMAIL,
      PHONE,
      TITLE,
      MESSAGE,
      USER_TO,
      EMAIL_TO,
      EMAIL_CC,
      PHONE_TO,
      CREATE_BY,
      CREATE_DATE,
      ATTACH_FILE
    )
    VALUES(
      p_CONTACT_CODE,
      p_FULLNAME,
      p_EMAIL,
      p_PHONE,
      p_TITLE,
      p_MESSAGE,
      p_USER_TO,
      p_EMAIL_TO,
      p_EMAIL_CC,
      p_PHONE_TO,
      p_CREATE_BY,
      SYSDATE,
      p_ATTACH_FILE
    );
  COMMIT;
END INSERT_CONTACT;
  
  PROCEDURE getContactFilter(
    p_contactCode   IN VARCHAR,
    p_message       IN VARCHAR,
    p_startDate     IN VARCHAR,
    p_endDate       IN VARCHAR,
    p_isSend        IN VARCHAR,
    p_recordset     OUT SYS_REFCURSOR
  )IS
    v_where       VARCHAR2(3000);
    v_condition   VARCHAR2(50);
    v_sql         VARCHAR(4000);
  BEGIN
    v_where       := '';
    v_condition   := '';
    
    IF p_contactCode IS NOT NULL THEN
      v_wHere := v_where || v_condition || ' UPPER(CONTACT_CODE) like ''%' || UPPER(p_contactCode)|| '%''';
      v_condition := ' and';
    END IF;
    
    IF p_message IS NOT NULL THEN
      v_where:= v_where || v_condition || ' UPPER(MESSAGE) like ''%' || UPPER(p_message) ||'%''';
      v_condition := ' and';
    END IF;
    
    IF p_endDate IS NOT NULL THEN
      v_where:= v_where|| v_condition || ' CREATE_DATE <= (TO_DATE('''|| p_endDate ||''', ''dd/mm/yyyy'') + 1)';
      v_condition := ' and';
    END IF;
    
    IF p_isSend = 'Y' THEN
          v_where:=v_where||v_condition||' SEND_DATE IS NOT NULL';
          v_condition := ' and';
      ELSIF p_isSend = 'N' THEN
          v_where:=v_where||v_condition||' SEND_DATE IS NULL';
          v_condition := ' and';
      END IF;
      
      IF v_where IS NOT NULL THEN
          v_where := ' WHERE ' || v_where;
      END IF;
      
      v_sql := 'SELECT 
          ID,
          PARENT_ID,
          CONTACT_CODE,
          FULLNAME,
          EMAIL,
          PHONE,
          TITLE,
          MESSAGE,
          USER_TO,
          EMAIL_TO,
          EMAIL_CC,
          PHONE_TO,
          CREATE_BY,
          CREATE_DATE,
          SEND_DATE,
          ATTACH_FILE,
          CASE
          WHEN SEND_DATE IS NOT NULL THEN ''Đã gửi''
          ELSE ''Chưa gửi''
          END SEND_DATE
      FROM CONTACTS ' || v_where || ' ORDER BY CREATE_DATE DESC';
      
      Dbms_Output.Put_Line(v_sql);
      Open p_recordset For v_sql;
      
  END getContactFilter;
end pk_contact;
/

