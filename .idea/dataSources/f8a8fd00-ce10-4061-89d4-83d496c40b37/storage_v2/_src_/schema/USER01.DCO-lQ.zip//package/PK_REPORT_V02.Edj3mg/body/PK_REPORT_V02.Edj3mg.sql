create PACKAGE BODY PK_REPORT_V02 AS
 PROCEDURE getList
      ( 
                P_DATA OUT SYS_REFCURSOR
      ) AS
        SQL_STRING VARCHAR2(1000);
      BEGIN
         
          SQL_STRING :=  'select * from SYS_GOI_CUOC_CVQT order by TEN_GOI ';
                          
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
      END;    
END PK_REPORT_V02;
/

