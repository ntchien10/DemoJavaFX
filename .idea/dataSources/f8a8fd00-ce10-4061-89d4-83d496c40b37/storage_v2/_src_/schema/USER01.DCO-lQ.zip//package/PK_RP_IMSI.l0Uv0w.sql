create PACKAGE PK_RP_IMSI AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
    PROCEDURE getListLu(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    );
    PROCEDURE getListPsc(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    );
    PROCEDURE getListSilent(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    );  
    PROCEDURE getListQuocGiaLu(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_TENQUOCGIA IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ); 
    PROCEDURE getListTenQuocGiaLu(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_TENQUOCGIA IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ); 
    PROCEDURE getListQuocGiaPsc(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_TENQUOCGIA IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    );
    PROCEDURE getListQuocGiaSilent(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_TENQUOCGIA IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    );
    PROCEDURE getListMaMangLu(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_TENQUOCGIA IN VARCHAR,
        P_MAMANG IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ); 
    PROCEDURE getListMaMangPsc(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_TENQUOCGIA IN VARCHAR,
        P_MAMANG IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    );
    PROCEDURE getListMaMangSilent(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_TENQUOCGIA IN VARCHAR,
        P_MAMANG IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    );
END PK_RP_IMSI;
/

