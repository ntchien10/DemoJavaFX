create PACKAGE BODY PK_DATA_USER AS

  PROCEDURE getList(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);
    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';
        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and GIOTAO > TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and GIOTAO < TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        SQL_STRING := 'SELECT * FROM CHIEN_TEST WHERE 1=1 ' || V_WHERE1 || V_WHERE2  ;
        

--        V_WHERE1 := ' ';
--        
--            V_WHERE1 := V_WHERE1 || ' and GIOTAO BETWEEN TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'') AND TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
--        IF P_TUNGAY IS NULL THEN
--            V_WHERE1 := ' ';
--        END IF;
--        
--        IF P_DENNGAY IS NULL THEN
--            V_WHERE1 := ' ';
--        END IF;
--        
--        SQL_STRING := 'SELECT * FROM CHIEN_TEST WHERE 1=1 ' || V_WHERE1 ;
        
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
    END getList;

    
END PK_DATA_USER;
/

