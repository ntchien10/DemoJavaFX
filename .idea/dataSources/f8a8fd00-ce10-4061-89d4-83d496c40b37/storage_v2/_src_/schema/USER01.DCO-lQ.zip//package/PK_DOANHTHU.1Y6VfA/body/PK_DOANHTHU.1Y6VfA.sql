create PACKAGE BODY PK_DOANHTHU AS

    PROCEDURE getList(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);
    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';
        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        SQL_STRING := 'SELECT * FROM RP_SL_DT_GC_CVQT_OUT_DAILY WHERE 1=1 ' || V_WHERE1 || V_WHERE2  ;
        
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
    END getList;

    PROCEDURE getDays(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);
    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';
        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        SQL_STRING := 'SELECT * FROM RP_SL_DT_GC_CVQT_OUT_DAILY WHERE 1=1 ' || V_WHERE1 || V_WHERE2  ;
        
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
    END getDays;
    
    PROCEDURE getGoi(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
--        P_NGAY IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);
    V_WHERE3 VARCHAR2(1000);
    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';
        V_WHERE3 := ' ';
        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
--        IF P_NGAY IS NOT NULL THEN
--            V_WHERE3 := V_WHERE3 || ' and NGAY = TO_DATE ('''||P_NGAY||''', ''dd-mm-yyyy'')' ;
--        END IF;
        
        SQL_STRING := 'SELECT * FROM RP_SL_DT_GC_CVQT_OUT_DAILY WHERE 1=1 ' || V_WHERE1 || V_WHERE2;
        
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
    END getGoi;
    
    PROCEDURE getGoiByTime(
        P_NGAY IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);
    V_WHERE3 VARCHAR2(1000);
    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';
        V_WHERE3 := ' ';
        

        IF P_NGAY IS NOT NULL THEN
            V_WHERE3 := V_WHERE3 || ' and NGAY = TO_DATE ('''||P_NGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        SQL_STRING := 'SELECT * FROM RP_SL_DT_GC_CVQT_OUT_DAILY WHERE 1=1 ' || V_WHERE3 ;
        
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
    END getGoiByTime;
END PK_DOANHTHU;
/

