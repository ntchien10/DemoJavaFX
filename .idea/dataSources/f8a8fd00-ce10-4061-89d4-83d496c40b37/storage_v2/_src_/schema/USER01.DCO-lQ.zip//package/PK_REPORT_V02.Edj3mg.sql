create PACKAGE PK_REPORT_V02 AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
     PROCEDURE getList
      ( 
                P_DATA OUT SYS_REFCURSOR
      );
END PK_REPORT_V02;
/

