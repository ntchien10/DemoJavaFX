create trigger NHANVIEN_TRIG
    before insert
    on NHANVIEN
    for each row
begin  
   if inserting then 
      if :NEW."ID" is null then 
         select S_NHANVIEN.nextval into :NEW."ID" from dual; 
      end if; 
   end if; 
end;
/

