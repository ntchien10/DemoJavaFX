create PACKAGE BODY PK_OUTBOUND AS

  PROCEDURE getList(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_TENGOI IN VARCHAR,
        P_CTKV IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
  SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);
    V_WHERE3 VARCHAR2(1000);
    V_WHERE4 VARCHAR2(1000);
    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';
        V_WHERE3 := ' ';
        V_WHERE4 := ' ';
        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY >= TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY <= TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_TENGOI IS NOT NULL THEN
            V_WHERE3 := V_WHERE3 || ' and TEN_GOI = ''' || P_TENGOI ||'''';
        END IF;
        
        IF P_CTKV IS NOT NULL THEN
            V_WHERE4 := V_WHERE4 || ' and CTKV = ''' || P_CTKV ||'''';
        END IF;
        
--        SQL_STRING := 'SELECT * FROM RP_SL_DT_GC_CVQT_OUTBOUND WHERE 1=1 ' || V_WHERE1 || V_WHERE2 ||V_WHERE3 ;
        SQL_STRING := 'SELECT NGAY,TEN_GOI,CTKV, ROUND(SAN_LUONG_MOC,2) as SAN_LUONG_MOC, ROUND(SAN_LUONG_MTC,2) as SAN_LUONG_MTC, ROUND(SAN_LUONG_SMS_MO,2) as SAN_LUONG_SMS_MO,
ROUND(SAN_LUONG_SMS_MT,2) as SAN_LUONG_SMS_MT,ROUND(SAN_LUONG_DATA,2) as SAN_LUONG_DATA FROM RP_SL_DT_GC_CVQT_OUTBOUND WHERE 1=1 ' || V_WHERE1 || V_WHERE2 ||V_WHERE3 ||V_WHERE4;

--        V_WHERE1 := ' ';
--        
--            V_WHERE1 := V_WHERE1 || ' and NGAY BETWEEN TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'') AND TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
--        IF P_TUNGAY IS NULL THEN
--            V_WHERE1 := ' ';
--        END IF;
--        
--        IF P_DENNGAY IS NULL THEN
--            V_WHERE1 := ' ';
--        END IF;
--        
--        IF P_TENGOI IS NOT NULL THEN
--            V_WHERE3 := V_WHERE3 || ' and TEN_GOI = ''' || P_TENGOI ||'''';
--        END IF;
--        
--        SQL_STRING := 'SELECT * FROM RP_SL_DT_GC_CVQT_OUTBOUND WHERE 1=1 ' || V_WHERE1 || V_WHERE3 ;
        
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
    END getList;

END PK_OUTBOUND;
/

