create PACKAGE BODY PK_REPORT_CHIEN AS

  PROCEDURE getList_OUTBOUND(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_TENGOI IN VARCHAR,
        P_CTKV IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
  SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);
    V_WHERE3 VARCHAR2(1000);
    V_WHERE4 VARCHAR2(1000);
    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';
        V_WHERE3 := ' ';
        V_WHERE4 := ' ';
        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY >= TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY <= TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_TENGOI IS NOT NULL THEN
            V_WHERE3 := V_WHERE3 || ' and TEN_GOI = ''' || P_TENGOI ||'''';
        END IF;
        
        IF P_CTKV IS NOT NULL THEN
            V_WHERE4 := V_WHERE4 || ' and CTKV = ''' || P_CTKV ||'''';
        END IF;
        

        SQL_STRING := 'SELECT NGAY,TEN_GOI,CTKV, ROUND(SAN_LUONG_MOC,2) as SAN_LUONG_MOC, ROUND(SAN_LUONG_MTC,2) as SAN_LUONG_MTC, ROUND(SAN_LUONG_SMS_MO,2) as SAN_LUONG_SMS_MO,
ROUND(SAN_LUONG_SMS_MT,2) as SAN_LUONG_SMS_MT,ROUND(SAN_LUONG_DATA,2) as SAN_LUONG_DATA FROM RP_SL_DT_GC_CVQT_OUTBOUND WHERE 1=1 ' || V_WHERE1 || V_WHERE2 ||V_WHERE3 ||V_WHERE4;

        
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
    END getList_OUTBOUND;

    PROCEDURE getList_DOANHTHU(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);
    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';
        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        SQL_STRING := 'SELECT * FROM RP_SL_DT_GC_CVQT_OUT_DAILY WHERE 1=1 ' || V_WHERE1 || V_WHERE2  ;
        
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
    END getList_DOANHTHU;

    PROCEDURE getDays_DOANHTHU(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);
    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';
        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        SQL_STRING := 'SELECT * FROM RP_SL_DT_GC_CVQT_OUT_DAILY WHERE 1=1 ' || V_WHERE1 || V_WHERE2  ;
        
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
    END getDays_DOANHTHU;
    
    PROCEDURE getGoi_DOANHTHU(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
--        P_NGAY IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);
    V_WHERE3 VARCHAR2(1000);
    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';
        V_WHERE3 := ' ';
        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
--        IF P_NGAY IS NOT NULL THEN
--            V_WHERE3 := V_WHERE3 || ' and NGAY = TO_DATE ('''||P_NGAY||''', ''dd-mm-yyyy'')' ;
--        END IF;
        
        SQL_STRING := 'SELECT * FROM RP_SL_DT_GC_CVQT_OUT_DAILY WHERE 1=1 ' || V_WHERE1 || V_WHERE2;
        
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
    END getGoi_DOANHTHU;
    
    PROCEDURE getGoiByTime_DOANHTHU(
        P_NGAY IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);
    V_WHERE3 VARCHAR2(1000);
    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';
        V_WHERE3 := ' ';
        

        IF P_NGAY IS NOT NULL THEN
            V_WHERE3 := V_WHERE3 || ' and NGAY = TO_DATE ('''||P_NGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        SQL_STRING := 'SELECT * FROM RP_SL_DT_GC_CVQT_OUT_DAILY WHERE 1=1 ' || V_WHERE3 ;
        
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
    END getGoiByTime_DOANHTHU;
    
    PROCEDURE getList_REPORT_V02
      ( 
                P_DATA OUT SYS_REFCURSOR
      ) AS
        SQL_STRING VARCHAR2(1000);
      BEGIN
         
          SQL_STRING :=  'select * from SYS_GOI_CUOC_CVQT order by TEN_GOI ';
                          
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
      END getList_REPORT_V02;   
      
      PROCEDURE getListLu_IMSI(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);

    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';

        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;

        SQL_STRING := 'select * from rp_imsi_lu where 1=1'|| V_WHERE1 ||V_WHERE2;
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
        
    END getListLu_IMSI;

    PROCEDURE getListPsc_IMSI(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);

    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';

        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;

    
        SQL_STRING := 'select * from rp_imsi_psc where 1=1'|| V_WHERE1 ||V_WHERE2;
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
        
    END getListPsc_IMSI;
    
    PROCEDURE getListSilent_IMSI(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);

    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';

        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;

    
        SQL_STRING := 'select * from rp_imsi_silent where 1=1'|| V_WHERE1 ||V_WHERE2;
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
        
    END getListSilent_IMSI;
    
    PROCEDURE getListQuocGiaLu_IMSI(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_TENQUOCGIA IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);
    V_WHERE3 VARCHAR2(1000);

    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';
        V_WHERE3 := ' ';
        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd/mm/yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd/mm/yyyy'')' ;
        END IF;

        IF P_TENQUOCGIA IS NOT NULL THEN
            V_WHERE3 := V_WHERE3 || ' and TEN_QUOC_GIA =''' || P_TENQUOCGIA ||'''';
        END IF;
    
        SQL_STRING := 'select DISTINCT TEN_QUOC_GIA from rp_imsi_lu where 1=1'|| V_WHERE1 ||V_WHERE2 || V_WHERE3;
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
        
    END getListQuocGiaLu_IMSI;
    
    PROCEDURE getListTenQuocGiaLu_IMSI(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_TENQUOCGIA IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);
    V_WHERE3 VARCHAR2(1000);

    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';
        V_WHERE3 := ' ';
        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd/mm/yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd/mm/yyyy'')' ;
        END IF;

        IF P_TENQUOCGIA IS NOT NULL THEN
            V_WHERE3 := V_WHERE3 || ' and TEN_QUOC_GIA =''' || P_TENQUOCGIA ||'''';
        END IF;
    
        SQL_STRING := 'select * from rp_imsi_lu where 1=1'|| V_WHERE1 ||V_WHERE2 || V_WHERE3;
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
        
    END getListTenQuocGiaLu_IMSI;
    
    PROCEDURE getListQuocGiaPsc_IMSI(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_TENQUOCGIA IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);
    V_WHERE3 VARCHAR2(1000);

    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';
        V_WHERE3 := ' ';
        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;

        IF P_TENQUOCGIA IS NOT NULL THEN
            V_WHERE3 := V_WHERE3 || ' and TEN_QUOC_GIA =''' || P_TENQUOCGIA ||'''';
        END IF;
    
        SQL_STRING := 'select * from rp_imsi_psc where 1=1'|| V_WHERE1 ||V_WHERE2 || V_WHERE3;
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
        
    END getListQuocGiaPsc_IMSI;
    
    PROCEDURE getListQuocGiaSilent_IMSI(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_TENQUOCGIA IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);
    V_WHERE3 VARCHAR2(1000);

    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';
        V_WHERE3 := ' ';
        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;

        IF P_TENQUOCGIA IS NOT NULL THEN
            V_WHERE3 := V_WHERE3 || ' and TEN_QUOC_GIA =''' || P_TENQUOCGIA ||'''';
        END IF;
    
        SQL_STRING := 'select * from rp_imsi_silent where 1=1'|| V_WHERE1 ||V_WHERE2 || V_WHERE3;
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
        
    END getListQuocGiaSilent_IMSI;
    
    PROCEDURE getListMaMangLu_IMSI(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_TENQUOCGIA IN VARCHAR,
        P_MAMANG IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);
    V_WHERE3 VARCHAR2(1000);
    V_WHERE4 VARCHAR2(1000);

    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';
        V_WHERE3 := ' ';
        V_WHERE4 := ' ';
        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;

        IF P_TENQUOCGIA IS NOT NULL THEN
            V_WHERE3 := V_WHERE3 || ' and TEN_QUOC_GIA =''' || P_TENQUOCGIA ||'''';
        END IF;

        IF P_MAMANG IS NOT NULL THEN
            V_WHERE4 := V_WHERE4 || ' and MA_MANG =''' || P_MAMANG ||'''';
        END IF;
        
        SQL_STRING := 'select * from rp_imsi_lu where 1=1'|| V_WHERE1 ||V_WHERE2 || V_WHERE3 || V_WHERE4;
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
        
    END getListMaMangLu_IMSI;
    
    PROCEDURE getListMaMangPsc_IMSI(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_TENQUOCGIA IN VARCHAR,
        P_MAMANG IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);
    V_WHERE3 VARCHAR2(1000);
    V_WHERE4 VARCHAR2(1000);

    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';
        V_WHERE3 := ' ';
        V_WHERE4 := ' ';
        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;

        IF P_TENQUOCGIA IS NOT NULL THEN
            V_WHERE3 := V_WHERE3 || ' and TEN_QUOC_GIA =''' || P_TENQUOCGIA ||'''';
        END IF;

        IF P_MAMANG IS NOT NULL THEN
            V_WHERE4 := V_WHERE4 || ' and MA_MANG =''' || P_MAMANG ||'''';
        END IF;
        
        SQL_STRING := 'select * from rp_imsi_psc where 1=1'|| V_WHERE1 ||V_WHERE2 || V_WHERE3 || V_WHERE4;
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
        
    END getListMaMangPsc_IMSI;
    
     PROCEDURE getListMaMangSilent_IMSI(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_TENQUOCGIA IN VARCHAR,
        P_MAMANG IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);
    V_WHERE3 VARCHAR2(1000);
    V_WHERE4 VARCHAR2(1000);

    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';
        V_WHERE3 := ' ';
        V_WHERE4 := ' ';
        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;

        IF P_TENQUOCGIA IS NOT NULL THEN
            V_WHERE3 := V_WHERE3 || ' and TEN_QUOC_GIA =''' || P_TENQUOCGIA ||'''';
        END IF;

        IF P_MAMANG IS NOT NULL THEN
            V_WHERE4 := V_WHERE4 || ' and MA_MANG =''' || P_MAMANG ||'''';
        END IF;
        
        SQL_STRING := 'select * from rp_imsi_silent where 1=1'|| V_WHERE1 ||V_WHERE2 || V_WHERE3 || V_WHERE4;
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
        
    END getListMaMangSilent_IMSI;
END PK_REPORT_CHIEN;
/

