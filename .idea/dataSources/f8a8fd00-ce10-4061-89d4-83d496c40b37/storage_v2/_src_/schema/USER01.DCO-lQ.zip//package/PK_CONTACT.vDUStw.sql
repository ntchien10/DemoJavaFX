create PACKAGE PK_CONTACT AS 

  PROCEDURE INSERT_CONTACT(
      p_CONTACT_CODE        CONTACTS.CONTACT_CODE%TYPE,
      p_FULLNAME            CONTACTS.FULLNAME%TYPE,
      p_EMAIL               CONTACTS.EMAIL%TYPE,
      p_PHONE               CONTACTS.PHONE%TYPE,
      p_TITLE               CONTACTS.TITLE%TYPE,
      p_MESSAGE             CONTACTS.MESSAGE%TYPE,
      p_USER_TO             CONTACTS.USER_TO%TYPE,
      p_EMAIL_TO            CONTACTS.EMAIL_TO%TYPE,
      p_EMAIL_CC            CONTACTS.EMAIL_CC%TYPE,
      p_PHONE_TO            CONTACTS.PHONE_TO%TYPE,
      p_CREATE_BY           CONTACTS.CREATE_BY%TYPE,
      p_ATTACH_FILE         CONTACTS.ATTACH_FILE%TYPE
  );
  
  PROCEDURE getContactFilter(
      p_contactCode         IN VARCHAR,
      p_message             IN VARCHAR,
      p_startDate           IN VARCHAR,
      p_endDate             IN VARCHAR,
      p_isSend              IN VARCHAR,
      p_recordset           OUT SYS_REFCURSOR
  );

END PK_CONTACT;
/

