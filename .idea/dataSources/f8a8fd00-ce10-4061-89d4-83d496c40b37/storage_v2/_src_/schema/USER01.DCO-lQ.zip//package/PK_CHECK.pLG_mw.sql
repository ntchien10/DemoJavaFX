create PACKAGE PK_CHECK AS 
  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
  PROCEDURE GET_CHECK_IN(
        p_username IN VARCHAR2,
        p_start_time IN DATE,
        p_end_time IN DATE,
        p_status IN VARCHAR2,
        p_address IN VARCHAR2,
        p_note IN VARCHAR2,
        p_data OUT SYS_REFCURSOR 
    );

END PK_CHECK;
/

