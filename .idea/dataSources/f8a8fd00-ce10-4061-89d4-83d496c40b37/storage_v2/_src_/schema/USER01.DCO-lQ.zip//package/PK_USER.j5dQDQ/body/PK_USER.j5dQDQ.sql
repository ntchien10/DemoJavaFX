create PACKAGE BODY PK_USER AS

    PROCEDURE getList(
        P_USERNAME IN VARCHAR2,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE VARCHAR2(1000);
    BEGIN
        V_WHERE := ' ';
        
        IF P_USERNAME IS NOT NULL THEN
            V_WHERE := V_WHERE || ' and USERNAME = ''' || P_USERNAME ||'''';
        END IF;
        
        SQL_STRING := 'SELECT * FROM SYS_USERS WHERE 1=1 ' || V_WHERE  ;
        
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
    END getList;

    /* delete user*/
    PROCEDURE deleteByUsername(
        P_USERNAME IN VARCHAR2

    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE VARCHAR2(1000);
    BEGIN
        V_WHERE := ' ';
        
        IF P_USERNAME IS NOT NULL THEN
            
            V_WHERE := V_WHERE || ' and USERNAME = ''' || P_USERNAME ||'''';
        END IF;
    
        SQL_STRING := 'DELETE FROM SYS_USERS WHERE 1=1'|| V_WHERE  ;
        
        Dbms_Output.Put_Line(SQL_STRING);
--        OPEN P_DATA FOR SQL_STRING;
    END deleteByUsername;
END PK_USER;
/

