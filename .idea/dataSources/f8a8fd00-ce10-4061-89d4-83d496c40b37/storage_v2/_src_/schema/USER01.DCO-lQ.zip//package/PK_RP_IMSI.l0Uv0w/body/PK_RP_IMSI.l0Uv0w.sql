create PACKAGE BODY PK_RP_IMSI AS

  PROCEDURE getListLu(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);

    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';

        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;

        SQL_STRING := 'select * from rp_imsi_lu where 1=1'|| V_WHERE1 ||V_WHERE2;
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
        
    END getListLu;

    PROCEDURE getListPsc(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);

    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';

        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;

    
        SQL_STRING := 'select * from rp_imsi_psc where 1=1'|| V_WHERE1 ||V_WHERE2;
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
        
    END getListPsc;
    
    PROCEDURE getListSilent(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);

    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';

        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;

    
        SQL_STRING := 'select * from rp_imsi_silent where 1=1'|| V_WHERE1 ||V_WHERE2;
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
        
    END getListSilent;
    
    PROCEDURE getListTenQuocGiaLu(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_TENQUOCGIA IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);
    V_WHERE3 VARCHAR2(1000);

    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';
        V_WHERE3 := ' ';
        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd/mm/yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd/mm/yyyy'')' ;
        END IF;

        IF P_TENQUOCGIA IS NOT NULL THEN
            V_WHERE3 := V_WHERE3 || ' and TEN_QUOC_GIA =''' || P_TENQUOCGIA ||'''';
        END IF;
    
        SQL_STRING := 'select DISTINCT TEN_QUOC_GIA from rp_imsi_lu where 1=1'|| V_WHERE1 ||V_WHERE2 || V_WHERE3;
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
        
    END getListTenQuocGiaLu;
    
    PROCEDURE getListQuocGiaLu(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_TENQUOCGIA IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);
    V_WHERE3 VARCHAR2(1000);

    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';
        V_WHERE3 := ' ';
        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd/mm/yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd/mm/yyyy'')' ;
        END IF;

        IF P_TENQUOCGIA IS NOT NULL THEN
            V_WHERE3 := V_WHERE3 || ' and TEN_QUOC_GIA =''' || P_TENQUOCGIA ||'''';
        END IF;
    
        SQL_STRING := 'select * from rp_imsi_lu where 1=1'|| V_WHERE1 ||V_WHERE2 || V_WHERE3;
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
        
    END getListQuocGiaLu;
    
    PROCEDURE getListQuocGiaPsc(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_TENQUOCGIA IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);
    V_WHERE3 VARCHAR2(1000);

    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';
        V_WHERE3 := ' ';
        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;

        IF P_TENQUOCGIA IS NOT NULL THEN
            V_WHERE3 := V_WHERE3 || ' and TEN_QUOC_GIA =''' || P_TENQUOCGIA ||'''';
        END IF;
    
        SQL_STRING := 'select * from rp_imsi_psc where 1=1'|| V_WHERE1 ||V_WHERE2 || V_WHERE3;
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
        
    END getListQuocGiaPsc;
    
    PROCEDURE getListQuocGiaSilent(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_TENQUOCGIA IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);
    V_WHERE3 VARCHAR2(1000);

    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';
        V_WHERE3 := ' ';
        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;

        IF P_TENQUOCGIA IS NOT NULL THEN
            V_WHERE3 := V_WHERE3 || ' and TEN_QUOC_GIA =''' || P_TENQUOCGIA ||'''';
        END IF;
    
        SQL_STRING := 'select * from rp_imsi_silent where 1=1'|| V_WHERE1 ||V_WHERE2 || V_WHERE3;
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
        
    END getListQuocGiaSilent;
    
    PROCEDURE getListMaMangLu(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_TENQUOCGIA IN VARCHAR,
        P_MAMANG IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);
    V_WHERE3 VARCHAR2(1000);
    V_WHERE4 VARCHAR2(1000);

    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';
        V_WHERE3 := ' ';
        V_WHERE4 := ' ';
        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;

        IF P_TENQUOCGIA IS NOT NULL THEN
            V_WHERE3 := V_WHERE3 || ' and TEN_QUOC_GIA =''' || P_TENQUOCGIA ||'''';
        END IF;

        IF P_MAMANG IS NOT NULL THEN
            V_WHERE4 := V_WHERE4 || ' and MA_MANG =''' || P_MAMANG ||'''';
        END IF;
        
        SQL_STRING := 'select * from rp_imsi_lu where 1=1'|| V_WHERE1 ||V_WHERE2 || V_WHERE3 || V_WHERE4;
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
        
    END getListMaMangLu;
    
    PROCEDURE getListMaMangPsc(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_TENQUOCGIA IN VARCHAR,
        P_MAMANG IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);
    V_WHERE3 VARCHAR2(1000);
    V_WHERE4 VARCHAR2(1000);

    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';
        V_WHERE3 := ' ';
        V_WHERE4 := ' ';
        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;

        IF P_TENQUOCGIA IS NOT NULL THEN
            V_WHERE3 := V_WHERE3 || ' and TEN_QUOC_GIA =''' || P_TENQUOCGIA ||'''';
        END IF;

        IF P_MAMANG IS NOT NULL THEN
            V_WHERE4 := V_WHERE4 || ' and MA_MANG =''' || P_MAMANG ||'''';
        END IF;
        
        SQL_STRING := 'select * from rp_imsi_psc where 1=1'|| V_WHERE1 ||V_WHERE2 || V_WHERE3 || V_WHERE4;
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
        
    END getListMaMangPsc;
    
     PROCEDURE getListMaMangSilent(
        P_TUNGAY IN VARCHAR,
        P_DENNGAY IN VARCHAR,
        P_TENQUOCGIA IN VARCHAR,
        P_MAMANG IN VARCHAR,
        P_DATA OUT SYS_REFCURSOR
    ) AS
    SQL_STRING VARCHAR2(10000);
    V_WHERE1 VARCHAR2(1000);
    V_WHERE2 VARCHAR2(1000);
    V_WHERE3 VARCHAR2(1000);
    V_WHERE4 VARCHAR2(1000);

    BEGIN
        V_WHERE1 := ' ';
        V_WHERE2 := ' ';
        V_WHERE3 := ' ';
        V_WHERE4 := ' ';
        
        IF P_TUNGAY IS NOT NULL THEN
            V_WHERE1 := V_WHERE1 || ' and NGAY > TO_DATE ('''||P_TUNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;
        
        IF P_DENNGAY IS NOT NULL THEN
            V_WHERE2 := V_WHERE2 || ' and NGAY < TO_DATE ('''||P_DENNGAY||''', ''dd-mm-yyyy'')' ;
        END IF;

        IF P_TENQUOCGIA IS NOT NULL THEN
            V_WHERE3 := V_WHERE3 || ' and TEN_QUOC_GIA =''' || P_TENQUOCGIA ||'''';
        END IF;

        IF P_MAMANG IS NOT NULL THEN
            V_WHERE4 := V_WHERE4 || ' and MA_MANG =''' || P_MAMANG ||'''';
        END IF;
        
        SQL_STRING := 'select * from rp_imsi_silent where 1=1'|| V_WHERE1 ||V_WHERE2 || V_WHERE3 || V_WHERE4;
        Dbms_Output.Put_Line(SQL_STRING);
        OPEN P_DATA FOR SQL_STRING;
        
    END getListMaMangSilent;
END PK_RP_IMSI;
/

