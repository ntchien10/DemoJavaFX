create PACKAGE BODY PK_CHECK AS

  PROCEDURE GET_CHECK_IN(
        p_username IN VARCHAR2,
        p_start_time IN DATE,
        p_end_time IN DATE,
        p_status IN VARCHAR2,
        p_address IN VARCHAR2,
        p_note IN VARCHAR2,
        p_data OUT SYS_REFCURSOR 
    ) AS
    v_where VARCHAR2(500);
    sql_string VARCHAR2(1000);
    BEGIN
        IF p_username IS NOT NULL THEN
            v_where := v_where || ' AND UPPER(USERNAME) = UPPER(''' || p_username || ''')';
        END IF;
        IF p_start_time IS NOT NULL THEN
            v_where := v_where || ' AND UPPER(START_TIME) = UPPER(''' || p_start_time || ''')';
        END IF;
        IF p_end_time IS NOT NULL THEN
            v_where := v_where || ' AND UPPER(END_TIME) = UPPER(''' || p_end_time || ''')';
        END IF;
        IF p_status IS NOT NULL THEN
            v_where := v_where || ' AND UPPER(STATUS) = UPPER(''' || p_status || ''')';
        END IF;
        IF p_address IS NOT NULL THEN
            v_where := v_where || ' AND UPPER(ADDRESS) = UPPER(''' || p_address || ''')';
        END IF;
        IF p_note IS NOT NULL THEN
            v_where := v_where || ' AND UPPER(NOTE) = UPPER(''' || p_note || ''')';
        END IF;
        

        sql_string := 'INSERT INTO (username, start_time, status, address, note)
                       VALUES(p_username, p_start_time, p_status, p_address, p_note)';

        DBMS_OUTPUT.PUT_LINE(sql_string);
        OPEN p_data FOR sql_string;
    -- TODO: Implementation required for PROCEDURE PK_USERS.GET_USER_LIST
    NULL;
  END GET_CHECK_IN;

END PK_CHECK;
/

