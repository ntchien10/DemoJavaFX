create TYPE CELL_OFF_RECTYPE AS OBJECT 
( 
  start_date date,
  end_date date,
  bscid varchar2(20),
  cellid varchar2(50),
  cellname varchar2(50),
  
  constructor function CELL_OFF_RECTYPE return self as result
);
/

