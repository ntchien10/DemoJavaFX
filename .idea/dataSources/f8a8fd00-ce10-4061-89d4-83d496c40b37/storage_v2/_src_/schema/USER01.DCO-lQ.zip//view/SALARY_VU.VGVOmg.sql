create view SALARY_VU as
SELECT   e.last_name , d.DEPARTMENT_NAME, e.SALARY, j.JOB_TITLE, j.MIN_SALARY ||'->'||j.MAX_SALARY as JOB_GRADES
    FROM    EMPLOYEES e
    JOIN jobs j USING (JOB_ID)
    join departments d USING (department_id)
/

