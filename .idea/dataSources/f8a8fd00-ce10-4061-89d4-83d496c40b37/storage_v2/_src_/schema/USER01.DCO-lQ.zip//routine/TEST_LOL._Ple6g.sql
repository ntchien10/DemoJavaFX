create PROCEDURE TEST_LOL(p_NONAME_ID NUMBER, v_NONAME OUT VARCHAR2,v_DAME OUT NUMBER, v_DIFFERENT OUT NUMBER) IS 
BEGIN
  DBMS_OUTPUT.PUT_LINE('Parameter p_NONAME_ID=' || p_NONAME_ID);
  Select Emp.NONAME
        ,Emp.DAME
        ,Emp.DIFFERENT
  Into   v_NONAME
        ,v_DAME
        ,v_DIFFERENT
  From   LOL Emp
  Where  Emp.NONAME_Id = p_noname_id;
  --
  -- Ghi ra màn hình Console.
  --
  Dbms_Output.Put_Line('Found Record!');
  Dbms_Output.Put_Line(' v_NONAME= ' || v_NONAME);
  Dbms_Output.Put_Line(' v_DAME= ' || v_DAME);
  Dbms_Output.Put_Line(' v_DIFFERENT= ' || v_DIFFERENT);
Exception
  When No_Data_Found Then
     -- Ghi ra màn hình Console.
     Dbms_Output.Put_Line('No Record found with p_NONAME_ID = ' || p_NONAME_ID);
END TEST_LOL;
/

