create PACKAGE PK_USER AS 

    PROCEDURE getList(
        P_USERNAME IN VARCHAR2,
        P_DATA OUT SYS_REFCURSOR
    );
    PROCEDURE deleteByUsername(
        P_USERNAME IN VARCHAR2

    );
END PK_USER;
/

