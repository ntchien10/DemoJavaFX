create trigger SYS_USERS_TRIG
    before insert
    on SYS_USERS
    for each row
BEGIN
  if(:new.ID is null) then
  SELECT SYS_USERS_SEQ.nextval
  INTO :new.ID
  FROM dual;
  end if;
END;


select * from RP_SL_DT_GC_CVQT_OUTBOUND

Create Sequence My_Sequence;
Select My_Sequence.Currval From Dual;
/

