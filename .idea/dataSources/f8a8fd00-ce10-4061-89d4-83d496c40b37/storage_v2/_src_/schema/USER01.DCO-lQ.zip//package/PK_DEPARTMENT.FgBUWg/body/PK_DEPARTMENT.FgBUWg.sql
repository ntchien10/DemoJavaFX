create package body pk_department as

    function getDeptName 
        (dept_id NUMBER)
        return VARCHAR is new_string VARCHAR2(30);
        begin
            select department_v2.dept_name
                into new_string
                from department_v2;
            return (new_string);
        end;

    procedure getAllByName 
        (dept_name VARCHAR) is
            getAll VARCHAR2(2000);          
        begin
            getAll := 'select * from department_v2 where dept_name like dept_name';
        end;

end pk_department;
/

