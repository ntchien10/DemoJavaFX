create view DEPT50 as
SELECT  employee_id  EMPNO, last_name EMPLOYEE, DEPT_ID DEPTNO
    FROM    EMP
    where DEPT_ID=50
    with check option
/

