create trigger SYS_GOI_CUOC_CVQT_TRIG
    before insert
    on SYS_GOI_CUOC_CVQT
    for each row
BEGIN
  if(:new.ID is null) then
  SELECT SYS_GOI_CUOC_CVQT_SEQ.nextval
  INTO :new.ID
  FROM dual;
  end if;
END;
/

